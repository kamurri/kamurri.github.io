+++
# Custom widget.
# An example of using the custom widget to create your own homepage section.
# To create more sections, duplicate this file and edit the values below as desired.
widget = "custom"
active = true
date = 2020-08-09

# Note: a full width section format can be enabled by commenting out the `title` and `subtitle` with a `#`.
title = "Teaching"
#subtitle = "Average instructor rating: 4.8/5"

# Order that this section will appear in.
weight = 120

+++

### Instructor
Principles of Economics \\ Pilates, Barre, and Ballet Burn

### Teaching Assistant
Principles of Statistics, Statistics for Engineers and Scientists, Design and Analysis of Experiments, Introduction to Bayesian Statistics, Statistical Methods for Research \\
Intermediate Microeconomics, Intermediate Macroeconomics, Behavioral and Experimental Economics

### Upper Division Mathematics Tutor 
Linear Algebra, Discrete Mathematics, Mathematics for Engineers, Multivariate Calculus, and Ordinary Differential  Equations
